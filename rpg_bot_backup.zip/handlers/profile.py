# ============================================================
# profile.py — профиль персонажа и команда /help
# ============================================================

import sys
sys.path.append('/content/rpg_bot')

from telegram import Update
from telegram.ext import ContextTypes
from database import get_player
from game.balance import exp_to_next_level

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 <b>Осколки Вечности — команды</b>\n\n"
        "👤 <b>Персонаж</b>\n"
        "/profile — твои характеристики\n"
        "/stats — распределить очки статов\n\n"
        "⚔️ <b>Бой и мир</b>\n"
        "/location — текущая локация\n"
        "/fight — найти врага для боя\n"
        "/inventory — твой инвентарь\n\n"
        "🏪 <b>Прочее</b>\n"
        "/shop — магазин\n"
        "/quests — журнал квестов\n"
        "/top — таблица лидеров\n\n"
        "<i>Больше команд откроется по мере прокачки!</i>",
        parse_mode='HTML'
    )

async def profile_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    p = get_player(user.id)

    if not p:
        await update.message.reply_text("❌ Сначала создай персонажа — напиши /start")
        return

    # Прогресс опыта
    exp_needed = exp_to_next_level(p['level'])
    exp_pct    = int((p['exp'] / exp_needed) * 10)
    exp_bar    = '█' * exp_pct + '░' * (10 - exp_pct)

    # Прогресс HP
    hp_pct  = int((p['hp'] / p['max_hp']) * 10)
    hp_bar  = '█' * hp_pct + '░' * (10 - hp_pct)

    # Прогресс маны
    mp_pct  = int((p['mana'] / p['max_mana']) * 10)
    mp_bar  = '█' * mp_pct + '░' * (10 - mp_pct)

    await update.message.reply_text(
        f"👤 <b>{p['name']}</b>\n"
        f"⭐ Уровень: <b>{p['level']}</b>  |  📍 {p['location_id']}\n\n"
        f"❤️ HP:   {hp_bar} {p['hp']}/{p['max_hp']}\n"
        f"🔵 Мана: {mp_bar} {p['mana']}/{p['max_mana']}\n"
        f"✨ Опыт: {exp_bar} {p['exp']}/{exp_needed}\n\n"
        f"━━━━━━━━━━━━━━━\n"
        f"💪 Сила:      <b>{p['strength']}</b>\n"
        f"🤸 Ловкость:  <b>{p['agility']}</b>\n"
        f"🔮 Интуиция:  <b>{p['intuition']}</b>\n"
        f"❤️ Живучесть: <b>{p['vitality']}</b>\n"
        f"🧠 Мудрость:  <b>{p['wisdom']}</b>\n"
        f"🍀 Удача:     <b>{p['luck']}</b>\n"
        f"━━━━━━━━━━━━━━━\n"
        f"💰 Золото: <b>{p['gold']}</b>  |  "
        f"🎒 Вес: <b>{p['carry_weight']}</b>\n"
        + (f"\n🔸 Очков статов: <b>{p['stat_points']}</b> — напиши /stats"
           if p['stat_points'] > 0 else ""),
        parse_mode='HTML'
    )

print('✅ handlers/profile.py создан!')
