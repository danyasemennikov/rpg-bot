# ============================================================
# location.py — отображение локации и агрессия мобов
# ============================================================

import sys, random, asyncio
sys.path.append('/content/rpg_bot')

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from database import get_player
from game.locations import get_location, get_connected_locations, LOCATIONS
from game.mobs import get_mob

# ────────────────────────────────────────
# ОТОБРАЖЕНИЕ ЛОКАЦИИ
# ────────────────────────────────────────

def build_location_message(player: dict, location: dict) -> tuple:
    """Возвращает (текст, клавиатура) для текущей локации."""

    loc_name  = location['name']
    loc_desc  = location['description']
    lvl_range = f"Ур. {location['level_min']}–{location['level_max']}" \
                if not location['safe'] else "⚠️ Безопасная зона"

    text = f"📍 <b>{loc_name}</b>  |  {lvl_range}\n"
    text += f"<i>{loc_desc}</i>\n\n"

    keyboard = []

    # ── Мобы ──
    if location['mobs']:
        text += "👁️ <b>Существа поблизости:</b>\n"
        for mob_id in location['mobs']:
            mob = get_mob(mob_id)
            if not mob:
                continue
            agr_tag = " <b>[агр]</b>" if mob['aggressive'] else ""
            lvl_diff = mob['level'] - player['level']

            # Цвет сложности
            if lvl_diff >= 3:
                diff = "💀"   # намного сильнее
            elif lvl_diff >= 1:
                diff = "🔴"   # сильнее
            elif lvl_diff == 0:
                diff = "🟡"   # равный
            elif lvl_diff >= -2:
                diff = "🟢"   # слабее
            else:
                diff = "⚫"   # слишком слабый (мало опыта)

            text += f"{diff} {mob['name']}  Ур.{mob['level']}{agr_tag}\n"
            keyboard.append([InlineKeyboardButton(
                f"⚔️ Атаковать {mob['name']}",
                callback_data=f"attack_{mob_id}"
            )])
        text += "\n"

    # ── Ресурсы ──
    if location['gather']:
        text += "🌿 <b>Можно собрать:</b> "
        text += ", ".join(g[2] for g in location['gather']) + "\n"
        keyboard.append([InlineKeyboardButton("🌿 Собирать ресурсы", callback_data="gather")])
        text += "\n"

    # ── Сервисы ──
    service_buttons = []
    for service in location.get('services', []):
        if service == 'shop':
            service_buttons.append(InlineKeyboardButton("🏪 Магазин", callback_data="shop"))
        elif service == 'inn':
            service_buttons.append(InlineKeyboardButton("🏨 Таверна", callback_data="inn"))
        elif service == 'quest_board':
            service_buttons.append(InlineKeyboardButton("📋 Квесты", callback_data="quests"))
    if service_buttons:
        keyboard.append(service_buttons)

    # ── Переходы в другие локации ──
    connected = get_connected_locations(location['id'])
    if connected:
        text += "🗺️ <b>Перейти в:</b>\n"
        nav_buttons = []
        for conn_loc in connected:
            req_level = conn_loc['level_min']
            can_go    = player['level'] >= req_level or conn_loc['safe']
            label     = f"➡️ {conn_loc['name']}"
            if not can_go:
                label = f"🔒 {conn_loc['name']} (Ур.{req_level})"
            nav_buttons.append(InlineKeyboardButton(
              label,
              callback_data=f"goto_{conn_loc['id']}" if can_go else f"locked_{conn_loc['id']}"
            ))
        keyboard.append(nav_buttons)

    # ── Статус игрока ──
    text += f"\n❤️ {player['hp']}/{player['max_hp']}  " \
            f"🔵 {player['mana']}/{player['max_mana']}  " \
            f"💰 {player['gold']}"

    return text, InlineKeyboardMarkup(keyboard)


# ────────────────────────────────────────
# КОМАНДА /location
# ────────────────────────────────────────

async def location_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    p    = get_player(user.id)

    if not p:
        await update.message.reply_text("❌ Сначала создай персонажа — /start")
        return

    location = get_location(p['location_id'])
    if not location:
        await update.message.reply_text("❌ Локация не найдена!")
        return

    text, keyboard = build_location_message(dict(p), location)

    msg = await update.message.reply_text(text, reply_markup=keyboard, parse_mode='HTML')

    # Запускаем агрессию мобов если локация опасная
    if not location['safe']:
        context.application.create_task(
            schedule_mob_aggro(context, user.id, location, msg.message_id)
        )


# ────────────────────────────────────────
# ПЕРЕХОД МЕЖДУ ЛОКАЦИЯМИ
# ────────────────────────────────────────

async def handle_location_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data  = query.data

    print(f"DEBUG: получен callback = '{data}'")

    if data == 'noop':
        await query.answer()
        return

    user = query.from_user
    p    = get_player(user.id)

    if data.startswith('goto_'):
        new_loc_id = data.replace('goto_', '')
        new_loc    = get_location(new_loc_id)

        if not new_loc:
            await query.answer("❌ Локация не найдена!", show_alert=True)
            return

        # Проверка уровня
        if not new_loc['safe'] and p['level'] < new_loc['level_min']:
            await query.answer(
                f"❌ Нужен {new_loc['level_min']} уровень!",
                show_alert=True
            )
            return

        await query.answer()
        # Обновляем локацию в БД
        import sqlite3
        from database import get_connection
        conn = get_connection()
        conn.execute(
            'UPDATE players SET location_id=? WHERE telegram_id=?',
            (new_loc_id, user.id)
        )
        conn.commit()
        conn.close()

        # Обновляем сообщение
        p = dict(get_player(user.id))
        text, keyboard = build_location_message(p, new_loc)
        await query.edit_message_text(text, reply_markup=keyboard, parse_mode='HTML')

        # Запускаем агрессию в новой локации
        if not new_loc['safe']:
            context.application.create_task(
                schedule_mob_aggro(context, user.id, new_loc, query.message.message_id)
            )


# ────────────────────────────────────────
# АГРЕССИЯ МОБОВ (таймер)
# ────────────────────────────────────────

async def schedule_mob_aggro(context, telegram_id: int, location: dict, message_id: int):
    """
    Для каждого агрессивного моба в локации — ждём рандомное время
    и атакуем если игрок всё ещё здесь и уровень подходит.
    """
    aggressive_mobs = [
        get_mob(mid) for mid in location['mobs']
        if get_mob(mid) and get_mob(mid)['aggressive']
    ]

    tasks = []
    for mob in aggressive_mobs:
        delay = random.randint(5, 60)  # рандом 5-60 секунд
        tasks.append(aggro_attack(context, telegram_id, mob, location['id'], delay))

    await asyncio.gather(*tasks)


async def aggro_attack(context, telegram_id: int, mob: dict, location_id: str, delay: int):
    """Ждёт delay секунд, потом проверяет и атакует."""
    await asyncio.sleep(delay)

    # Проверяем что игрок всё ещё в этой локации
    p = get_player(telegram_id)
    if not p:
        return
    if p['location_id'] != location_id:
        return  # ушёл — не атакуем
    if p['in_battle']:
        return  # уже в бою

    # Проверка уровня: атакует только если уровень игрока <= уровень моба + 1
    if p['level'] > mob['level'] + 1:
        return  # игрок слишком силён — моб трусит

    # Моб атакует! Отправляем уведомление
    try:
        await context.bot.send_message(
            chat_id=telegram_id,
            text=(
                f"⚠️ <b>{mob['name']}</b> нападает на тебя!\n\n"
                f"Ур. {mob['level']}  ❤️ {mob['hp']} HP\n\n"
                f"Ответь на атаку!"
            ),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⚔️ Принять бой!", callback_data=f"fight_{mob['id']}"),
                InlineKeyboardButton("🏃 Сбежать!",     callback_data=f"flee_{mob['id']}"),
            ]])
        )
    except Exception:
        pass  # игрок заблокировал бота или другая ошибка

print('✅ handlers/location.py создан!')
