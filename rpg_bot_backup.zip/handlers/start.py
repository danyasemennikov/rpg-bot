# ============================================================
# start.py — регистрация и выбор стартовых статов
# ============================================================

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

import sys
sys.path.append('/content/rpg_bot')
from database import get_player, create_player, player_exists
from game.balance import calc_max_hp, calc_max_mana

GAME_NAME = "⚔️ Осколки Вечности"
STAT_POINTS = 6  # стартовые очки для распределения

# Список статов для интерфейса
STATS_LIST = [
    ('strength',  '💪 Сила'),
    ('agility',   '🤸 Ловкость'),
    ('intuition', '🔮 Интуиция'),
    ('vitality',  '❤️ Живучесть'),
    ('wisdom',    '🧠 Мудрость'),
    ('luck',      '🍀 Удача'),
]

def build_stats_keyboard(stats: dict, points_left: int) -> InlineKeyboardMarkup:
    """Строит клавиатуру распределения статов."""
    keyboard = []
    for key, label in STATS_LIST:
        val = stats[key]
        # Кнопка минус активна только если стат > 1
        btn_minus = InlineKeyboardButton(
            '➖' if val > 1 else '·',
            callback_data=f'stat_minus_{key}' if val > 1 else 'stat_noop'
        )
        btn_plus = InlineKeyboardButton(
            '➕' if points_left > 0 else '·',
            callback_data=f'stat_plus_{key}' if points_left > 0 else 'stat_noop'
        )
        btn_label = InlineKeyboardButton(f'{label}: {val}', callback_data='stat_noop')
        keyboard.append([btn_minus, btn_label, btn_plus])

    # Кнопка подтверждения
    if points_left == 0:
        keyboard.append([InlineKeyboardButton('✅ Начать игру!', callback_data='stat_confirm')])
    else:
        keyboard.append([InlineKeyboardButton(f'Осталось очков: {points_left}', callback_data='stat_noop')])

    return InlineKeyboardMarkup(keyboard)

def stats_text(stats: dict, points_left: int) -> str:
    """Текст сообщения при распределении статов."""
    hp   = calc_max_hp(stats['vitality'])
    mana = calc_max_mana(stats['wisdom'])
    return (
        f"⚔️ <b>Распредели стартовые очки</b>\n\n"
        f"Очков осталось: <b>{points_left}</b>\n\n"
        f"❤️ HP: <b>{hp}</b>  |  🔵 Мана: <b>{mana}</b>\n\n"
        f"Нажимай ➕ и ➖ чтобы распределить статы.\n"
        f"Когда закончишь — нажми <b>✅ Начать игру!</b>"
    )

# ────────────────────────────────────────
# КОМАНДА /start
# ────────────────────────────────────────

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    # Уже зарегистрирован?
    if player_exists(user.id):
        player = get_player(user.id)
        await update.message.reply_text(
            f"👋 С возвращением, <b>{player['name']}</b>!\n\n"
            f"❤️ HP: {player['hp']}/{player['max_hp']}  "
            f"🔵 Мана: {player['mana']}/{player['max_mana']}\n"
            f"⭐ Уровень: {player['level']}  |  💰 Золото: {player['gold']}\n\n"
            f"Используй /help чтобы увидеть все команды.",
            parse_mode='HTML'
        )
        return

    # Новый игрок — спрашиваем имя
    context.user_data['registering'] = True
    await update.message.reply_text(
        f"🌟 <b>Добро пожаловать в {GAME_NAME}!</b>\n\n"
        f"Земли погружаются во тьму, древние осколки силы разбросаны по миру...\n"
        f"Только настоящий герой сможет собрать их все.\n\n"
        f"✍️ <b>Как зовут твоего героя?</b>\n"
        f"<i>(просто напиши имя в чат)</i>",
        parse_mode='HTML'
    )

# ────────────────────────────────────────
# ВВОД ИМЕНИ
# ────────────────────────────────────────

async def handle_name_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает ввод имени персонажа."""
    if not context.user_data.get('registering'):
        return  # не в процессе регистрации

    name = update.message.text.strip()

    # Валидация имени
    if len(name) < 2:
        await update.message.reply_text("❌ Имя слишком короткое! Минимум 2 символа.")
        return
    if len(name) > 20:
        await update.message.reply_text("❌ Имя слишком длинное! Максимум 20 символов.")
        return

    # Сохраняем имя и переходим к статам
    context.user_data['reg_name'] = name
    context.user_data['reg_stats'] = {
        'strength': 1, 'agility': 1, 'intuition': 1,
        'vitality': 1, 'wisdom': 1,  'luck': 1
    }
    context.user_data['reg_points'] = STAT_POINTS

    stats  = context.user_data['reg_stats']
    points = context.user_data['reg_points']

    await update.message.reply_text(
        f"⚔️ Как-как, <b>{name}</b>, серьезно...? Ну ладно, проехали\n\n" + stats_text(stats, points),
        reply_markup=build_stats_keyboard(stats, points),
        parse_mode='HTML'
    )

# ────────────────────────────────────────
# КНОПКИ РАСПРЕДЕЛЕНИЯ СТАТОВ
# ────────────────────────────────────────

async def handle_stat_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает нажатия ➕ ➖ при распределении статов."""
    query = update.callback_query
    await query.answer()

    data = query.data

    if data == 'stat_noop':
        return

    stats  = context.user_data.get('reg_stats')
    points = context.user_data.get('reg_points')
    name   = context.user_data.get('reg_name')

    if not stats:
        await query.edit_message_text("❌ Сессия истекла. Напиши /start заново.")
        return

    # Плюс к стату
    if data.startswith('stat_plus_'):
        stat_key = data.replace('stat_plus_', '')
        if points > 0:
            stats[stat_key] += 1
            context.user_data['reg_points'] -= 1

    # Минус к стату
    elif data.startswith('stat_minus_'):
        stat_key = data.replace('stat_minus_', '')
        if stats[stat_key] > 1:
            stats[stat_key] -= 1
            context.user_data['reg_points'] += 1

    # Подтверждение
    elif data == 'stat_confirm':
        user = query.from_user
        create_player(user.id, user.username or '', name, stats)

        hp   = calc_max_hp(stats['vitality'])
        mana = calc_max_mana(stats['wisdom'])

        # Чистим временные данные
        context.user_data.clear()

        await query.edit_message_text(
            f"🎉 <b>Герой создан!</b>\n\n"
            f"⚔️ <b>{name}</b> выходит на дорогу...\n\n"
            f"❤️ HP: <b>{hp}</b>  |  🔵 Мана: <b>{mana}</b>\n\n"
            f"💪 Сила: {stats['strength']}  "
            f"🤸 Ловкость: {stats['agility']}  "
            f"🔮 Интуиция: {stats['intuition']}\n"
            f"❤️ Живучесть: {stats['vitality']}  "
            f"🧠 Мудрость: {stats['wisdom']}  "
            f"🍀 Удача: {stats['luck']}\n\n"
            f"Напиши /help чтобы узнать что делать дальше!",
            parse_mode='HTML'
        )
        return

    # Обновляем сообщение
    points = context.user_data['reg_points']
    await query.edit_message_text(
        f"⚔️ Как-как, <b>{name}</b>, серьезно...? Ну ладно, проехали\n\n" + stats_text(stats, points),
        reply_markup=build_stats_keyboard(stats, points),
        parse_mode='HTML'
    )

print('✅ handlers/start.py создан!')
