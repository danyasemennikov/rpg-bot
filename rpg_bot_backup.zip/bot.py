import sys
sys.path.append('/content/rpg_bot')

from telegram.ext import (
    ApplicationBuilder, CommandHandler,
    MessageHandler, CallbackQueryHandler, filters
)

from database import init_db
from handlers.start    import start_command, handle_name_input, handle_stat_buttons
from handlers.profile  import help_command, profile_command
from handlers.location import location_command, handle_location_buttons

BOT_TOKEN = "8725160392:AAE64UhndCqr53U5M98fJOesCIxmORkg5KM"

def main():
    init_db()
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler('start',    start_command))
    app.add_handler(CommandHandler('help',     help_command))
    app.add_handler(CommandHandler('profile',  profile_command))
    app.add_handler(CommandHandler('location', location_command))

    # Колбэки
    app.add_handler(CallbackQueryHandler(handle_stat_buttons,    pattern='^stat_'))
    app.add_handler(CallbackQueryHandler(handle_location_buttons, pattern='^(goto_|noop)'))

    # Текст (ввод имени)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_name_input))

    print('🚀 Осколки Вечности запущены!')
    app.run_polling()

if __name__ == '__main__':
    main()

print('✅ bot.py обновлён!')
